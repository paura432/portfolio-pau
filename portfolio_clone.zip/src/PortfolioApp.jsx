import { AppRouter } from './router/AppRouter'

export const PortfolioApp = () => {
  return (
	  <AppRouter />
  )
}